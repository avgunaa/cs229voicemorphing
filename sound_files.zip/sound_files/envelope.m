function env_new = envelope(sequence)

env = [];
hil = abs(hilbert(sequence));
val = 10;

for i = 1:length(hil)-val+1
   env = [env sum(hil(i:i+val-1))/val]; 
end

env = [env hil(end-val+1:end)'];

env_new = [];
hil_new = abs(hilbert(env'));
val = 70;

for i = 1:length(hil_new)-val+1
   env_new = [env_new sum(hil_new(i:i+val-1))/val]; 
end

env_new = [env_new hil_new(end-val+1:end)'];

figure
plot(sequence);
hold on
plot(env,'r');
plot(env_new,'g');
hold off